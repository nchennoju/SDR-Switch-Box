A couple things to keep in mind:

Arduino UNO - Switch box
Arduino NANO / CH340 - Data Logger


IMPORTS:
import tkinter as tk
import serial
import serial.tools.list_ports
import matplotlib.pyplot as plt


Install the following modules:
pip install pyserial
pip install matplotlib